package Modelo;

import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.lang.reflect.Type;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.google.gson.reflect.TypeToken;

import javafx.collections.FXCollections;
import javafx.collections.ObservableList;

public class tareaDAO {

	private ObservableList<Tarea> lista = FXCollections.observableArrayList();
	
	
	public tareaDAO() {
		cargarDesdeJson();
		
	}
	
	public ObservableList<Tarea> getLista(){	
		
		return lista;
	}
	
	
	public void añadirTarea(Tarea tareaAAñadir) {
		
		lista.add(tareaAAñadir);
		guardarEnJson();
	}
	
	
	public void borrarTarea(Tarea tareaBorrar) {
		
		lista.remove(tareaBorrar);
		guardarEnJson();
	}
	
	
	public void actualizarTarea(Tarea tarea, String nombreTarea, String descripcion, String fecha, String estado, String prioridad) {
		
		tarea.setNombreTarea(nombreTarea);
		tarea.setDescripcion(descripcion);
		tarea.setFecha(fecha);
		tarea.setEstado(estado);
		tarea.setPrioridad(prioridad);
		guardarEnJson();
	}
	
	
	private void guardarEnJson() {
		
		Gson gson = new GsonBuilder().setPrettyPrinting().create();
		
		try (FileWriter fw = new FileWriter("tareas.json")) {
			
			ArrayList<Tarea> listaParaGuardar = new ArrayList<>(lista);
				gson.toJson(listaParaGuardar, fw);
			
		} catch (IOException e) {
			e.printStackTrace();
		}
	}
	
	
	private void cargarDesdeJson() {
		Gson gson = new Gson();
			Type tipo = new TypeToken<ArrayList<Tarea>>() {}.getType();
		
		try (FileReader fr = new FileReader("tareas.json")) {
			ArrayList<Tarea> tareasCargadas = gson.fromJson(fr, tipo);
			
			if (tareasCargadas != null) {
				lista.setAll(tareasCargadas);
			}
		
		} catch (IOException e) {
			System.out.println("No se encontro el archivo json.");
		}
	}
	
	
	public int tareasPendientes() {
		
		int contador = 0;
		
		for (Tarea t : lista) {
			
			if (t.getEstado() != null && t.getEstado().trim().equalsIgnoreCase("Pendiente")) {
				contador++;
				
			}
		}
		
		return contador;
	}

	
	public int tareasCompletadasSemanal() {
	    int contador = 0;
	    
	    LocalDate hoy = LocalDate.now();
	    LocalDate haceUnaSemana = hoy.minusDays(7);
	    
	    
	    DateTimeFormatter formateador = DateTimeFormatter.ofPattern("dd/MM/yyyy");
	    
	    for (Tarea tarea : lista) {
	    	
	        if (tarea.getEstado() != null && tarea.getEstado().equalsIgnoreCase("Completado")) {
	            
	            if (tarea.getFecha() != null && !tarea.getFecha().isEmpty()) {
	            	
	                try {
	                    
	                    LocalDate fechaTarea = LocalDate.parse(tarea.getFecha(), formateador);
	                    
	                    
	                    if (fechaTarea.isAfter(haceUnaSemana) || fechaTarea.isEqual(haceUnaSemana)) {
	                        contador++;
	                    }
	                    
	                } catch (Exception e) {
	                    System.out.println("Error al transformar la fecha de la tarea: " + tarea.getFecha());
	                    
	                }
	            }
	        }
	    }
	    
	    return contador;
	}
	
	
	public int tareasCompletadasTotales() {
	    int contador = 0;
	    for (Tarea t : lista) {
	        if (t.getEstado() != null && t.getEstado().equalsIgnoreCase("Completado")) {
	            contador++;
	        }
	    }
	    return contador;
	}
	
	
public int tareasAltaPrioridad() {
		
		int contador = 0;
		
		for (Tarea t : lista) {
			
			if (t.getPrioridad() != null && t.getPrioridad().trim().equalsIgnoreCase("Alta") && t.getEstado().trim().equalsIgnoreCase("Pendiente")) {
				contador++;
				
			}
		}
		
		return contador;
	}
}
