package Controlador;

import java.time.DateTimeException;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;

import Modelo.Tarea;
import Modelo.tareaDAO;
import javafx.beans.value.ChangeListener;
import javafx.beans.value.ObservableValue;
import javafx.fxml.FXML;
import javafx.scene.control.Label;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.TextField;
import javafx.scene.control.cell.PropertyValueFactory;

public class Controlador {

	
	//Columnas Tabla
	@FXML
	private TableColumn<Tarea, String> colNombre;
	
	@FXML
	private TableColumn<Tarea, String> colDescripcion;
	
	@FXML
	private TableColumn<Tarea, String> colFecha;
	
	@FXML
	private TableColumn<Tarea, String> colEstado;
	
	@FXML
	private TableColumn<Tarea, String> colPrioridad;
	
	//Tabla Completa
	@FXML
	private TableView<Tarea> tablaTareas;
	
	//Respuestas
	@FXML
	private TextField respuestaNombre;
	
	@FXML
	private TextField respuestaDescripcion;
	
	@FXML
	private TextField respuestaFecha;
	
	@FXML
	private TextField respuestaEstado;
	
	@FXML
	private TextField respuestaPrioridad;
	
	@FXML
	private Label mensajesError;

	@FXML
	private Label apartadoTareasPendientes;

	@FXML
	private Label apartadoTareasCompletadasSemana;

	@FXML
	private Label lblPorcentaje;
	
	@FXML
	private Label apartadoTareasAltaPrioridad;
	
	
	private tareaDAO TareaDAO = new tareaDAO();

	
	@FXML
	public void initialize() {
		colNombre.setCellValueFactory(new PropertyValueFactory<>("nombreTarea"));
		colDescripcion.setCellValueFactory(new PropertyValueFactory<>("descripcion"));
		colFecha.setCellValueFactory(new PropertyValueFactory<>("fecha"));
		colEstado.setCellValueFactory(new PropertyValueFactory<>("estado"));
		colPrioridad.setCellValueFactory(new PropertyValueFactory<>("prioridad"));

		tablaTareas.setItems(TareaDAO.getLista());

		actualizarEstadisticas();
		
		tablaTareas.getSelectionModel().selectedItemProperty().addListener(new ChangeListener<Tarea>() {
			
			@Override
			public void changed(ObservableValue<? extends Tarea> observable, Tarea anterior, Tarea seleccionado) {
				
				if (seleccionado != null) {
					
					respuestaNombre.setText(seleccionado.getNombreTarea());
					respuestaDescripcion.setText(seleccionado.getDescripcion());
					
		            DateTimeFormatter formatter = DateTimeFormatter.ofPattern("dd/MM/yyyy");
		            
			            if (seleccionado.getFecha() != null) {
			                String fechaFormateada = seleccionado.getFecha().formatted(formatter);
			                	respuestaFecha.setText(fechaFormateada);
			            
			            }
	        		
					respuestaEstado.setText(String.valueOf(seleccionado.getEstado()));
				}
				
				mensajesError.setText("");
			}
			
		});
		
	}
	
	
	@FXML
	public void añadirTarea() {
		
		try {
			
	        String nombreTarea = respuestaNombre.getText();
	        String descripcion = respuestaDescripcion.getText();
	        
	        if (respuestaNombre.getText().isEmpty() || respuestaFecha.getText().isEmpty()) {
	            mensajesError.setText("Error: El nombre y la fecha son obligatorios.");
	            mensajesError.setStyle("-fx-text-fill: red;");
	            return;
	            
	        } else {
	        	mensajesError.setText("Se ha añadido correctamente la tarea.");
	        	mensajesError.setStyle("-fx-text-fill: green;");
	        }
	        
	        String fecha = null;
	        
	        String fechaStr = respuestaFecha.getText();

			try {
			   
			    DateTimeFormatter formatter = DateTimeFormatter.ofPattern("dd/MM/yyyy");
			    LocalDate.parse(fechaStr, formatter); 
			    
			    fecha = fechaStr; 
			    
			} catch (Exception e) {

			    mensajesError.setText("Error: El formato debe ser dd/MM/yyyy");
			    return;
			}	
	        
	        	String estado = respuestaEstado.getText();
	        	
	        	 if (!respuestaEstado.getText().equalsIgnoreCase("Pendiente") && !respuestaEstado.getText().equalsIgnoreCase("Completado")) {
	        		mensajesError.setText("Error: Hay algún fallo en el Estado");
	 	            return;
	 	            
	 	        }
	        		 
	        	String prioridad = respuestaPrioridad.getText();
	        	
	        	 if (!respuestaPrioridad.getText().equalsIgnoreCase("Alta") && !respuestaPrioridad.getText().equalsIgnoreCase("Media") && !respuestaPrioridad.getText().equalsIgnoreCase("Baja")) {
	        		mensajesError.setText("Error: Hay algún fallo en la prioridad");
	 	            return;
	 	            
	 	        } 
	        	 
	        
	        	Tarea nueva = new Tarea(nombreTarea, descripcion, fecha, estado, prioridad);
	       
	        TareaDAO.añadirTarea(nueva);
	        
	        actualizarEstadisticas();
	        
	        limpiarFormulario();
	        
	    } catch (Exception e) {
	        mensajesError.setText("Error: Formato de Fecha incorrecto.");
	    }
	}
	
	@FXML
	public void borrarTarea() {
		
		Tarea seleccionado = tablaTareas.getSelectionModel().getSelectedItem();

		if (seleccionado != null) {
			TareaDAO.borrarTarea(seleccionado);
			
			mensajesError.setText("Se ha borrado correctamente la tarea.");
			mensajesError.setStyle("-fx-text-fill: green;");
		}
		
		actualizarEstadisticas();
	}
	
	@FXML
	public void modificarTarea() {
		Tarea seleccionado = tablaTareas.getSelectionModel().getSelectedItem();

		if (seleccionado == null) {
			return;
			
		} else {
			mensajesError.setText("Se ha actualizado correctamente la tarea.");
			mensajesError.setStyle("-fx-text-fill: green;");
		}

		String nombreTarea = respuestaNombre.getText();
		
		String descripcion = respuestaDescripcion.getText();
		
		String fecha = null;
		
		String fechaStr = respuestaFecha.getText();

		try {
		   
		    DateTimeFormatter formatter = DateTimeFormatter.ofPattern("dd/MM/yyyy");
		    LocalDate.parse(fechaStr, formatter); 
		    
		    fecha = fechaStr; 
		    
		} catch (Exception e) {

		    mensajesError.setText("Error: El formato debe ser dd/MM/yyyy");
		    return;
		}	
			
		String estado = respuestaEstado.getText();
		
		String prioridad = respuestaPrioridad.getText();
    	
   	 if (!respuestaPrioridad.getText().equalsIgnoreCase("Alta") && !respuestaPrioridad.getText().equalsIgnoreCase("Media") && !respuestaPrioridad.getText().equalsIgnoreCase("Baja")) {
   		
   		 mensajesError.setText("Error: Hay algún fallo en la prioridad");
            return;
            
        } 
		
		
		TareaDAO.actualizarTarea(seleccionado, nombreTarea, descripcion, fecha, estado, prioridad);

		tablaTareas.refresh();
		
		actualizarEstadisticas();
		
		limpiarFormulario();
	}

	private void limpiarFormulario() {
		respuestaNombre.clear();
		respuestaDescripcion.clear();
		respuestaFecha.clear();
		respuestaEstado.clear();
		respuestaPrioridad.clear();
	}
	
	private void actualizarEstadisticas() {
	   
	    int pendientes = TareaDAO.tareasPendientes();
	    int completadasSemana = TareaDAO.tareasCompletadasSemanal();
	    int prioridad = TareaDAO.tareasAltaPrioridad();
	    
	    int completadasTotales = TareaDAO.tareasCompletadasTotales();
	    	int total = TareaDAO.getLista().size();

	    
		    apartadoTareasPendientes.setText(String.valueOf(pendientes));
		    apartadoTareasCompletadasSemana.setText(String.valueOf(completadasSemana));
		    apartadoTareasAltaPrioridad.setText(String.valueOf(prioridad));
	    
	    if (total > 0) {
	    	
	        int porcentaje = (completadasTotales * 100) / total;
	        lblPorcentaje.setText(porcentaje + "%");
	        
	    } else {
	        lblPorcentaje.setText("0%");
	        
	    }
	}
	
}