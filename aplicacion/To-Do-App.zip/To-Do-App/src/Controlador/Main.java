package Controlador;

import java.io.IOException;
import javafx.application.Application;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.image.Image;
import javafx.stage.Stage;

public class Main extends Application{

	@Override
	public void start(Stage stage) throws IOException {
		
		Parent root = FXMLLoader.load(getClass().getResource("../vista/main.fxml"));
		Scene scene = new Scene(root);
		stage.setTitle("TableView");
		stage.setScene(scene);
		stage.show();
		
		stage.getIcons().add(new Image("/vista/logo.png"));
	}
	
	public static void main(String[] args) {
		launch(args);
	}
	
	
	
}
